-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 14, 2018 at 06:52 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `find_job`
--
CREATE DATABASE IF NOT EXISTS `find_job` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `find_job`;

-- --------------------------------------------------------

--
-- Table structure for table `candidates`
--

CREATE TABLE `candidates` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dob` datetime NOT NULL,
  `image` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `sex` tinyint(4) NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `candidates`
--

INSERT INTO `candidates` (`id`, `user_id`, `name`, `dob`, `image`, `sex`, `address`, `phone`, `status`, `created_at`, `updated_at`) VALUES
(1, 5, 'Đặng Duy Long1', '1996-01-25 00:00:00', 'public/images/candidate/T7QjCKt3Avđặng duy long.jpg', 3, '54 Nguyễn Văn Linh, Tuy Hòa, Phú Yên', '0988936354', 0, '2018-03-14 05:16:50', '2018-03-14 05:19:23');

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE `companies` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `place` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `desc` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `website` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `view` int(11) NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`id`, `user_id`, `name`, `size`, `address`, `place`, `image`, `desc`, `website`, `phone`, `view`, `status`) VALUES
(1, 3, 'Công ty test', '5', '12 Nguyễn Văn Bảo, phường 5, quận Gò Vấp', '3', 'public/images/company/jLO8y6pdcQthiet-ke-logo-cong-ty-thuong-mai-phuong-bac-pbc_thumb_1466496409.jpg', '-Đây là nội dung test', 'https://laravel.com', '0988936352', 1, '0'),
(2, 2, 'Công ty test 2', '4', '12 Nguyễn Văn Bảo, phường 5, quận Gò Vấp', '2', 'public/images/company/0LDdoZ5SPDthiet-ke-logo-cong-ty-dung-dong.jpg', 'sadasdasdasdasdasdasdasdasdasd', 'https://laravel.com', '988936354', 1, '0'),
(3, 4, 'RIKKEISOFT', '5', 'Nam Tu Liem, Ha Noi', '2', 'public/images/company/h1wqBo5CNcrikkeisoft-logo-170-151.png', 'RIKKEISOFT là một trong những công ty hàng đầu tại Việt Nam về sản xuất phần mềm, đặc biệt là ứng dụng trên nền web và smartphone. Làm việc cho 100% khách hàng Nhật Bản.\r\n\r\nTháng 10 năm 2014 Rikkeisoft đã trở thành một trong 30 doanh nghiệp CNTT hàng đầu của Việt Nam, vừa được VINASA công bố, giới thiệu và quảng bá tới các khách hàng, đối tác tiềm năng tại gần 100 quốc gia, vùng lãnh thổ trên thế giới!\r\n\r\nRIKKEISOFT được thành lập ngày 06 tháng 04 năm 2012. Kể từ khi thành lập, chúng tôi luôn nỗ lực để tạo ra những sản phẩm mang tính sáng tạo có chất lượng tốt, cống hiến cho sự phát triển của xã hội. Sứ mệnh của chúng tôi là xây dựng nên cuộc sống tốt đẹp hơn nhờ có di động và Internet. Tầm nhìn của chúng tôi là trở thành một trong những công ty lớn nhất tại Việt Nam trong lĩnh vực smartphone, web và di động trong 5 năm tới.', 'https://RIKKEISOFT.com', '0988936354', 1, '0');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(9, '2014_10_12_000000_create_users_table', 1),
(10, '2014_10_12_100000_create_password_resets_table', 1),
(11, '2018_03_10_041737_create_companies_table', 1),
(12, '2018_03_10_045003_create_post_employers_table', 1),
(16, '2018_03_11_100748_create_settings_table', 2),
(20, '2018_03_12_073504_add_colum_place_in_companies', 3),
(22, '2018_03_12_190820_create_tags_table', 4),
(23, '2018_03_13_155309_add_colum_view_in_postemployer', 5),
(27, '2018_03_14_102430_create_candidates_table', 6);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `post_employers`
--

CREATE TABLE `post_employers` (
  `id` int(10) UNSIGNED NOT NULL,
  `company_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `qty_candidate` int(11) NOT NULL,
  `sex` tinyint(4) NOT NULL,
  `desc` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `requirement` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `working_form` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `experience` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slary` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `time_try` int(11) NOT NULL,
  `benefit` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `career` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `workplace` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration_date` datetime NOT NULL,
  `tags` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `view` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL COMMENT '0=> Đang chờ duyệt,1=>Đã duyệt,2=>Hết hạn,3=>Không được duyệt',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `post_employers`
--

INSERT INTO `post_employers` (`id`, `company_id`, `title`, `qty_candidate`, `sex`, `desc`, `requirement`, `working_form`, `level`, `experience`, `slary`, `time_try`, `benefit`, `career`, `workplace`, `contact`, `expiration_date`, `tags`, `view`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, 'Tuyển dụng C#1', 2, 2, 'Mô tả công việc1', 'Yêu cầu công việc1', '1', '3', '4', '6', 3, 'Quyền LợiQuyền Lợi1', NULL, '3', '{\"name_contact\":\"\\u0110\\u1eb7ng Duy Long\",\"email_contact\":\"dangduylong96@gmail.com\",\"address_contact\":\"12 Nguy\\u1ec5n V\\u0103n B\\u1ea3o, ph\\u01b0\\u1eddng 5, qu\\u1eadn G\\u00f2 V\\u1ea5p\",\"mobile_contact\":\"0988936354\"}', '2018-03-29 00:00:00', '[\"c#\",\"Javascript\"]', '1', 0, '2018-03-12 17:42:59', '2018-03-13 11:18:58'),
(2, 1, 'Tuyển dụng PHP', 2, 1, 'Mô tả công việc', 'Yêu cầu công việc', '3', '4', '4', '5', 4, 'Quyền LợiQuyền Lợi', NULL, '4', '{\"name_contact\":\"\\u0110\\u1eb7ng Duy Long\",\"email_contact\":\"dangduylong96@gmail.com\",\"address_contact\":\"12 Nguy\\u1ec5n V\\u0103n B\\u1ea3o, ph\\u01b0\\u1eddng 5, qu\\u1eadn G\\u00f2 V\\u1ea5p\",\"mobile_contact\":\"0988936354\"}', '2018-03-29 00:00:00', '[\"PHP\",\"webs\"]', '1', 0, '2018-03-12 17:43:49', '2018-03-12 17:43:49'),
(3, 1, 'Java Developers - Work in Da Nang', 5, 1, '-We are hiring 13 Java developers and 2 Java technical leaders for current and upcoming projects from US. \r\nCandidates must to work in Ho Chi Minh in 3-6 months before moving back to Da Nang \r\n\r\n-If you are looking for a professional working environment, a chance to work on hot technologies: full stack development with Java Spring MVC/Hibernate and AngularJS, let join us!\r\n\r\n-You will be the backbone of Formos and primarily responsible for the development of world-class software. You will work closely with local project teams including project managers, software architects, developers and testers. You will also communicate at times with our US based project managers so you must have good English communication skills.\r\n\r\n-Candidates must demonstrate a deep understanding best practices and have experience with key technology that we use on our projects. Attention to detail and willingness to learn are critical characteristics we are looking for. For the right candidates we offer a great career path to be promoted, very competitive benefits package, exciting projects, and a great team for you to be a part of.', '-Java development experience and skills\r\n-1 - 5 years for Junior and Senior Java developer position\r\n-5+ years for Java technical leader position\r\n-Experience with web enterprise-scale applications\r\n-Experience with Java Spring and related technologies in Spring such as Spring Data, Spring Security, Spring MVC, etc.,\r\n-Experience with Java SE 5-8, JDK, SDK\r\n-Experience or knowledge with AngularJS or other JavaScript frameworks (ReactJS/Node.js etc.)\r\n-Experience with JSON and RESTful Web services\r\n-Experience with Hibernate/JPA/iBatis (or another ORM framework)\r\n-Experience MySQL, or related SQL technologies\r\n-Honest, reliable, organized and detail oriented\r\n-For leader position\r\n-Able to provide technical solution\r\n-Must be seen as a leader and mentor to junior developers\r\n-Do code review for junior team members\r\n-Strong time management skills\r\n-Good English communication skills', '1', '1', '1', '10', 5, 'Formos provides an exciting, fun, open environment in which team members work with cutting edge software development tools and technologies to produce top-quality solutions for customers. We work hard and maintain a fast pace.', NULL, '4', '{\"name_contact\":\"\\u0110\\u1eb7ng Duy Long\",\"email_contact\":\"dangduylong96@gmail.com\",\"address_contact\":\"12 Nguy\\u1ec5n V\\u0103n B\\u1ea3o, ph\\u01b0\\u1eddng 5, qu\\u1eadn G\\u00f2 V\\u1ea5p\",\"mobile_contact\":\"0988936354\"}', '2018-03-26 00:00:00', '[\"MySQL\",\"Javascript\",\"2\"]', '1', 0, '2018-03-13 09:25:15', '2018-03-13 09:25:15'),
(4, 1, 'Java Developers - Work in Da Nang', 5, 1, '-We are hiring 13 Java developers and 2 Java technical leaders for current and upcoming projects from US. \r\nCandidates must to work in Ho Chi Minh in 3-6 months before moving back to Da Nang \r\n\r\n-If you are looking for a professional working environment, a chance to work on hot technologies: full stack development with Java Spring MVC/Hibernate and AngularJS, let join us!\r\n\r\n-You will be the backbone of Formos and primarily responsible for the development of world-class software. You will work closely with local project teams including project managers, software architects, developers and testers. You will also communicate at times with our US based project managers so you must have good English communication skills.\r\n\r\n-Candidates must demonstrate a deep understanding best practices and have experience with key technology that we use on our projects. Attention to detail and willingness to learn are critical characteristics we are looking for. For the right candidates we offer a great career path to be promoted, very competitive benefits package, exciting projects, and a great team for you to be a part of.', '-Java development experience and skills\r\n-1 - 5 years for Junior and Senior Java developer position\r\n-5+ years for Java technical leader position\r\n-Experience with web enterprise-scale applications\r\n-Experience with Java Spring and related technologies in Spring such as Spring Data, Spring Security, Spring MVC, etc.,\r\n-Experience with Java SE 5-8, JDK, SDK\r\n-Experience or knowledge with AngularJS or other JavaScript frameworks (ReactJS/Node.js etc.)\r\n-Experience with JSON and RESTful Web services\r\n-Experience with Hibernate/JPA/iBatis (or another ORM framework)\r\n-Experience MySQL, or related SQL technologies\r\n-Honest, reliable, organized and detail oriented\r\n-For leader position\r\n-Able to provide technical solution\r\n-Must be seen as a leader and mentor to junior developers\r\n-Do code review for junior team members\r\n-Strong time management skills\r\n-Good English communication skills', '1', '1', '1', '10', 5, 'Formos provides an exciting, fun, open environment in which team members work with cutting edge software development tools and technologies to produce top-quality solutions for customers. We work hard and maintain a fast pace.', NULL, '4', '{\"name_contact\":\"\\u0110\\u1eb7ng Duy Long\",\"email_contact\":\"dangduylong96@gmail.com\",\"address_contact\":\"12 Nguy\\u1ec5n V\\u0103n B\\u1ea3o, ph\\u01b0\\u1eddng 5, qu\\u1eadn G\\u00f2 V\\u1ea5p\",\"mobile_contact\":\"0988936354\"}', '2018-03-26 00:00:00', '[\"MySQL\",\"Javascript\",\"2\"]', '1', 0, '2018-03-13 09:26:20', '2018-03-13 09:26:20'),
(5, 1, 'Java Developers - Work in Da Nang', 5, 1, '-We are hiring 13 Java developers and 2 Java technical leaders for current and upcoming projects from US. \r\nCandidates must to work in Ho Chi Minh in 3-6 months before moving back to Da Nang \r\n\r\n-If you are looking for a professional working environment, a chance to work on hot technologies: full stack development with Java Spring MVC/Hibernate and AngularJS, let join us!\r\n\r\n-You will be the backbone of Formos and primarily responsible for the development of world-class software. You will work closely with local project teams including project managers, software architects, developers and testers. You will also communicate at times with our US based project managers so you must have good English communication skills.\r\n\r\n-Candidates must demonstrate a deep understanding best practices and have experience with key technology that we use on our projects. Attention to detail and willingness to learn are critical characteristics we are looking for. For the right candidates we offer a great career path to be promoted, very competitive benefits package, exciting projects, and a great team for you to be a part of.', '-Java development experience and skills\r\n-1 - 5 years for Junior and Senior Java developer position\r\n-5+ years for Java technical leader position\r\n-Experience with web enterprise-scale applications\r\n-Experience with Java Spring and related technologies in Spring such as Spring Data, Spring Security, Spring MVC, etc.,\r\n-Experience with Java SE 5-8, JDK, SDK\r\n-Experience or knowledge with AngularJS or other JavaScript frameworks (ReactJS/Node.js etc.)\r\n-Experience with JSON and RESTful Web services\r\n-Experience with Hibernate/JPA/iBatis (or another ORM framework)\r\n-Experience MySQL, or related SQL technologies\r\n-Honest, reliable, organized and detail oriented\r\n-For leader position\r\n-Able to provide technical solution\r\n-Must be seen as a leader and mentor to junior developers\r\n-Do code review for junior team members\r\n-Strong time management skills\r\n-Good English communication skills', '1', '1', '1', '10', 5, 'Formos provides an exciting, fun, open environment in which team members work with cutting edge software development tools and technologies to produce top-quality solutions for customers. We work hard and maintain a fast pace.', NULL, '4', '{\"name_contact\":\"\\u0110\\u1eb7ng Duy Long\",\"email_contact\":\"dangduylong96@gmail.com\",\"address_contact\":\"12 Nguy\\u1ec5n V\\u0103n B\\u1ea3o, ph\\u01b0\\u1eddng 5, qu\\u1eadn G\\u00f2 V\\u1ea5p\",\"mobile_contact\":\"0988936354\"}', '2018-03-26 00:00:00', '[\"MySQL\",\"Javascript\",\"2\"]', '1', 0, '2018-03-13 09:26:29', '2018-03-13 09:26:29'),
(6, 1, 'Web Developer (PHP/Java/JavaScript)', 2, 1, '-Lập kế hoạch phát triển và thiết kế website chuyên nghiệp.\r\n-Lập kế hoạch phát triển bản tin công ty thường niên, kỳ, tháng và theo chiến dịch để quảng bá sản phẩm của công ty.\r\n-Thu thập, phân tích thông tin thị trường, sản phẩm cập nhật xu hướng, các công cụ Marketing online, đề xuất với manager triển khai cho công ty\r\n-Quản lý và cập nhật thông tin trên các website công ty tin tuyển dụng, hình ảnh, banner, logo, video clip…\r\n-Hỗ trợ quản lý hệ thống phần cứng máy tính và các công việc liên quan đến vấn đề kỹ thuật tại văn phòng công ty.', '-Tốt nghiệp đại học chuyên ngành Công nghệ Thông tin, Bách khoa (quản trị, thiết kế website, thiết kế đồ họa, quản trị phần mềm, đa truyền thông…)\r\n-Có kinh nghiệm về lập trình website, các ứng dụng web.\r\n-Thành thạo một trong các ngôn ngữ lập trình: PHP/Java/JavaScript\r\n-Thành thạo HTML/CSS\r\n-Ưu tiên ứng viên đã có kinh nghiệm phát triển các website du lịch\r\n-Có kinh nghiệm về thiết kế website, sử dụng thành thạo các phần mềm thiết kế, tạo videos như Adobe, Photoshop, Illustrator, Indesign, Corel Draw, 3D, AI…là một lợi thế.\r\n-Ưu tiên ứng viên có thể sử dụng thành thạo tiếng anh', '1', '1', '3', '10', 1, '-Lương thỏa thuận\\\r\n-Có lương tháng 13\r\n-Thưởng theo hiệu quả công việc/thưởng quý.\r\n-Xét tăng lương hàng năm\r\n-Cơ hội thăng tiến lên Team Leader/Manager\r\n-Du lịch, company trip hàng năm.\r\n-Môi trường làm việc trẻ trung, chuyên nghiệp, năng động và quốc tế.\r\n-Các chế độ phúc lợi khác theo quy định của pháp luật.\r\n-Làm việc tại văn phòng Đà Nẵng.', NULL, '3', '{\"name_contact\":\"\\u0110\\u1eb7ng Duy Long\",\"email_contact\":\"dangduylong96@gmail.com\",\"address_contact\":\"12 Nguy\\u1ec5n V\\u0103n B\\u1ea3o, ph\\u01b0\\u1eddng 5, qu\\u1eadn G\\u00f2 V\\u1ea5p\",\"mobile_contact\":\"0988936354\"}', '2018-04-01 00:00:00', '[\"7\",\"2\",\"3\"]', '1', 0, '2018-03-13 09:32:17', '2018-03-13 09:32:17'),
(7, 1, 'PHP Developer (All levels)', 3, 1, 'Thiết kế, coding và kiểm thử hệ thống hoặc chức năng sau khi hoàn thành.\r\nXây dựng kế hoạch và quản lý tiến độ lập trình theo kế hoạch.\r\n\r\nNghiên cứu nắm bắt công nghệ mới.\r\n\r\nNơi làm việc: Hà Nội.', 'Kiến thức nền về PHP tốt, tư duy nhanh nhẹn, chăm chỉ.\r\n\r\nHiểu kiến thức về OOP, MVC, Coding conventions.\r\n\r\nCó kinh nghiệm làm việc với cơ sở dữ liệu (MySQL, PostgreSQL ...).\r\n\r\nCó kinh nghiệm làm việc với 1 trong các framework PHP (CakePHP, Yii, CodeIgniter, Laravel, Fuel ...).\r\n\r\nBiết các công cụ quản lý mã nguồn: SVN hoặc GIT.\r\n\r\nChủ động trong công việc, khả năng làm việc nhóm tốt.', '1', '2', '3', '9', 4, '- THƯỞNG: Tháng lương 13, thưởng tết, thưởng dự án, thưởng ngày lễ...\r\n- Xét TĂNG LƯƠNG 2 lần/ năm vào tháng 3 và tháng 9\r\n- PHỤ CẤP: tiếng Nhật hàng tháng (Nếu có bằng tiếng Nhật): N3: 1 triệu đồng ; N2: 3 triệu đồng , N1: 5 triệu đồng\r\n- Thưởng các ngày nghỉ Lễ, Tết\r\n- Nghỉ thứ 7, chủ nhật + 1 ngày phép/ tháng.\r\n- Có cơ hội đi onsite tại Nhật.\r\n- Tham gia lớp học tiếng Nhật với giáo viên người Nhật do công ty tổ chức.\r\n- MÔI TRƯỜNG LÀM VIỆC: năng động, thoải mái, chuyên nghiệp, công ty có bàn bóng bàn, máy chơi game, giờ phát nhạc theo yêu cầu giải lao giữa giờ và sau giờ làm việc căng thẳng, có thể tích lũy nhiều kinh nghiệm.\r\n- Các chế độ phúc lợi, chế độ của Công ty: Du lịch, sinh nhật, team building, relax,… tổ chức định kì và thường xuyên nhằm giúp nhân viên thoải mái sau những ngày làm việc căng thẳng.', NULL, '2', '{\"name_contact\":\"\\u0110\\u1eb7ng Duy Long\",\"email_contact\":\"dangduylong96@gmail.com\",\"address_contact\":\"12 Nguy\\u1ec5n V\\u0103n B\\u1ea3o, ph\\u01b0\\u1eddng 5, qu\\u1eadn G\\u00f2 V\\u1ea5p\",\"mobile_contact\":\"0988936354\"}', '2018-03-29 00:00:00', '[\"6\",\"PostgreSQL\",\"3\"]', '1', 0, '2018-03-13 09:38:21', '2018-03-13 09:38:21'),
(8, 3, '02 PHP/Drupal Developers - Up to 20M', 10, 1, 'Tham gia xây dựng hệ thống ERP và CRM phục vụ startup vận tải', 'Tối thiểu 1 năm kinh nghiệm với HTML5, CSS và Javascript và có khả năng phát triển PHP/Drupal.\r\nCó kinh nghiệm tích hợp API là một lợi thế.\r\nCó kiến thức và kinh nghiệm phát triển dự án theo mô hình Scrum/Kanban.', '1', '1', '2', '1', 1, 'Mức lương thỏa thuận Up to 20.000.000 đồng\r\nCơ hội được đào tạo trở thành leader, PM trong 3-6 tháng, trở thành một phần của đội ngũ quản lý.\r\n15 ngày nghỉ phép hàng tháng.\r\nThưởng hiệu quả hàng quý, xét duyệt tăng lương mỗi 6 tháng.\r\nGói cổ phiếu thưởng VSOP cho các cá nhân có thành tích cao.\r\nVị trí: Hà Nội, Remote (dành cho ứng viên thật sự xuất xắc)\r\nThử việc: 1 tháng - FULL lương', NULL, '2', '{\"name_contact\":\"\\u0110\\u1eb7ng Duy Long\",\"email_contact\":\"dangduylong96@gmail.com\",\"address_contact\":\"12 Nguy\\u1ec5n V\\u0103n B\\u1ea3o, ph\\u01b0\\u1eddng 5, qu\\u1eadn G\\u00f2 V\\u1ea5p\",\"mobile_contact\":\"0988936354\"}', '2018-03-30 00:00:00', '[\"7\",\"Drupal\",\"3\"]', '1', 0, '2018-03-13 09:52:48', '2018-03-13 09:52:48'),
(9, 3, 'Web Developer (PHP, AngularJS, knockout)', 1, 1, 'Develop company\'s plans.\r\nResearch new technology for the company\'s demands.\r\nAnalyze problems and suggest/provide solutions\r\nHave ability to work independently or in team', 'Being technically confident, flexibility, strong team spirit\r\nGood programming skills in the following technologies:\r\nStrong knowledge and experience in OOP and MVC Frameworks.\r\nExperience in usage one of the following modern PHP frameworks (CodeIgniter, Yii, Zend, CakePHP, Laravel)\r\nExperience with Angular 1.4 or Angular 2.0 or other javascript frameworks knocout,...\r\nExperience in SQL and Database: MongoDB, MySQL, PostgreSQL,NoSQL…\r\nGood knowledge in HTML5/XHTML/CSS/CSS3, Bootstrap, Foundation, SASS\r\nNice to have Node.js, React experienc', '1', '1', '3', '3', 3, 'Attractive salary and benefits;\r\nOpen-minded, young, and friendly working environment with promotion opportunities;\r\nEntitled to all social insurance benefits and high quality health insurance with many benefits for employees and their relatives', NULL, '3', '{\"name_contact\":\"dangduylong\",\"email_contact\":\"dangduylong96@gmail.com\",\"address_contact\":\"12 Nguy\\u1ec5n V\\u0103n B\\u1ea3o, ph\\u01b0\\u1eddng 5, qu\\u1eadn G\\u00f2 V\\u1ea5p\",\"mobile_contact\":\"0988936354\"}', '2018-03-29 00:00:00', '[\"5\",\"AngularJS\",\"3\"]', '1', 0, '2018-03-13 10:00:50', '2018-03-13 10:00:50');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `key` int(11) NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `name`, `key`, `value`) VALUES
(1, 'city', 11, '{\"2\":\"H\\u00e0 N\\u1ed9i\",\"3\":\"H\\u1ed3 Ch\\u00ed Minh\",\"4\":\"\\u0110\\u00e0 N\\u1eb5ng\",\"11\":\"Kh\\u00e1c\"}'),
(2, 'Size Company', 8, '{\"2\":\"D\\u01b0\\u1edbi 20 ng\\u01b0\\u1eddi\",\"4\":\"20-50 ng\\u01b0\\u1eddi\",\"5\":\"50-100 ng\\u01b0\\u1eddi\",\"6\":\"100-200 ng\\u01b0\\u1eddi\",\"7\":\"200-500 ng\\u01b0\\u1eddi\",\"8\":\"Tr\\u00ean 500 ng\\u01b0\\u1eddi\"}'),
(3, 'sex', 1, '{\"1\":\"Nam\",\"2\":\"N\\u1eef\",\"3\":\"Kh\\u00f4ng Y\\u00eau C\\u1ea7u\"}'),
(4, 'working_form', 5, '{\"1\":\"Nh\\u00e2n vi\\u00ean ch\\u00ednh th\\u1ee9c\",\"2\":\"Nh\\u00e2n vi\\u00ean th\\u1eddi v\\u1ee5\",\"3\":\"B\\u00e1n th\\u1eddi gian\",\"4\":\"L\\u00e0m th\\u00eam ngo\\u00e0i gi\\u1edd\",\"5\":\"Th\\u1ef1c t\\u1eadp sinh\"}'),
(5, 'level', 6, '{\"1\":\"\\u0110\\u1ea1i H\\u1ecdc\",\"2\":\"Cao \\u0110\\u1eb3ng\",\"3\":\"Trung C\\u1ea5p\",\"4\":\"Cao H\\u1ecdc\",\"5\":\"Ch\\u1ee9ng Ch\\u1ec9\",\"6\":\"Kh\\u00f4ng Y\\u00eau C\\u1ea7u\"}'),
(6, 'experience', 7, '{\"1\":\"Ch\\u01b0a c\\u00f3 kinh nghi\\u1ec7m\",\"2\":\"D\\u01b0\\u1edbi 1 n\\u0103m\",\"3\":\"1-2 n\\u0103m\",\"4\":\"2-3 n\\u0103m\",\"5\":\"3-4 n\\u0103m\",\"6\":\"4-5 n\\u0103m\",\"7\":\"Tr\\u00ean 5 n\\u0103m\"}'),
(7, 'slary', 11, '{\"1\":\"Th\\u1ecfa thu\\u1eadn khi ph\\u1ecfng v\\u1ea5n\",\"2\":\"D\\u01b0\\u1edbi 3 tri\\u1ec7u\",\"3\":\"3-5 tri\\u1ec7u\",\"4\":\"5-7 tri\\u1ec7u\",\"5\":\"7-10 tri\\u1ec7u\",\"6\":\"10-12 tri\\u1ec7u\",\"7\":\"12-15 tri\\u1ec7u\",\"8\":\"15-20 tri\\u1ec7u\",\"9\":\"20-25 tri\\u1ec7u\",\"10\":\"25-30 tri\\u1ec7u\",\"11\":\"Tr\\u00ean 30 tri\\u1ec7u\"}'),
(8, 'time_try', 5, '{\"1\":\"Nh\\u1eadn vi\\u1ec7c ngay\",\"2\":\"1 th\\u00e1ng\",\"3\":\"2 th\\u00e1ng\",\"4\":\"3 th\\u00e1ng\",\"5\":\"Trao \\u0111\\u1ed5i khi ph\\u1ecfng v\\u1ea5n\"}');

-- --------------------------------------------------------

--
-- Table structure for table `tags`
--

CREATE TABLE `tags` (
  `id` int(10) UNSIGNED NOT NULL,
  `post_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tags`
--

INSERT INTO `tags` (`id`, `post_id`, `name`) VALUES
(1, 1, 'c#'),
(2, 1, 'java'),
(3, 2, 'PHP'),
(4, 2, 'webs'),
(5, 4, 'MySQL'),
(6, 5, 'MySQL'),
(7, 5, 'Javascript'),
(8, 5, 'java'),
(9, 6, 'Javascript'),
(10, 6, 'java'),
(11, 6, 'PHP'),
(12, 7, 'MySQL'),
(13, 7, 'PostgreSQL'),
(14, 7, 'PHP'),
(15, 8, 'Javascript'),
(16, 8, 'Drupal'),
(17, 8, 'PHP'),
(18, 9, 'MySQL'),
(19, 9, 'AngularJS'),
(20, 9, 'PHP'),
(21, 1, 'c#'),
(22, 1, 'java'),
(23, 1, 'c#'),
(24, 1, 'java'),
(25, 1, 'c#'),
(26, 1, 'Javascript');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `type` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `status` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `type`, `email`, `password`, `remember_token`, `created_at`, `updated_at`, `status`) VALUES
(1, 'admin', 'dangduylong96@gmail.com', '$2y$10$qRGfdzyM3WvZixLSw9ijuu6geyhDPIsCT/jnaWYGUPZ/bd0pjZzoG', NULL, '2018-03-10 06:21:09', '2018-03-10 06:21:09', 1),
(2, 'employer', 'nhatuyendung@gmail.com', '$2y$10$Ym6zJFvlvimx7.Ryid4NBuIanPKJ0rZMfSqsJQA0gW7xcix0pfh5K', NULL, '2018-03-10 14:43:41', '2018-03-10 14:43:41', 1),
(3, 'employer', 'nhatuyendung1@gmail.com', '$2y$10$kW/d8sTx7Oyq2cy7I3UX4uwf/HrX7zKL/hw0UKVw536T/YpCyEm0q', NULL, '2018-03-10 14:44:24', '2018-03-10 14:44:24', 1),
(4, 'employer', 'nhatuyendung5@gmail.com', '$2y$10$KI1Tr0BeqkEytIdYeeuPA.9Qzrgmeyxdxsk82kSqXFGFT6Z/OWmr2', NULL, '2018-03-10 14:47:03', '2018-03-10 14:47:03', 1),
(5, 'candidate', 'ungvien@gmail.com', '$2y$10$1J50.6KuuyRdNplAZ.yM4ePgHy9fmceBLnWoL90blJjgLXx044yPi', NULL, '2018-03-14 03:46:28', '2018-03-14 03:46:28', 1),
(6, 'candidate', 'ungvien2@gmail.com', '$2y$10$Ew3nfqEvBnb7ZVjtZ2M3X.ZrwnSkRL1lYBSF0H88WJXccJjEhjDG.', NULL, '2018-03-14 03:48:08', '2018-03-14 03:48:08', 1),
(7, 'candidate', 'ungvien3@gmail.com', '$2y$10$hYP6Kr6EixnKlKlCymPVsOxnhvYDgee.jdnLSqnyHkNnmGpxPfbli', NULL, '2018-03-14 03:49:19', '2018-03-14 03:49:19', 1),
(8, 'candidate', 'ungvien4@gmail.com', '$2y$10$ZD8Lyv0nJFJhTMwluS79Ruou5DFc71Ax.JBg1B6f/3EzTPJcOs6Ty', NULL, '2018-03-14 03:51:22', '2018-03-14 03:51:22', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `candidates`
--
ALTER TABLE `candidates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `candidates_user_id_foreign` (`user_id`);

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `companies_user_id_foreign` (`user_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `post_employers`
--
ALTER TABLE `post_employers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `post_employers_company_id_foreign` (`company_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tags_post_id_foreign` (`post_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `candidates`
--
ALTER TABLE `candidates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `post_employers`
--
ALTER TABLE `post_employers`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tags`
--
ALTER TABLE `tags`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `candidates`
--
ALTER TABLE `candidates`
  ADD CONSTRAINT `candidates_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `companies`
--
ALTER TABLE `companies`
  ADD CONSTRAINT `companies_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `post_employers`
--
ALTER TABLE `post_employers`
  ADD CONSTRAINT `post_employers_company_id_foreign` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`);

--
-- Constraints for table `tags`
--
ALTER TABLE `tags`
  ADD CONSTRAINT `tags_post_id_foreign` FOREIGN KEY (`post_id`) REFERENCES `post_employers` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
